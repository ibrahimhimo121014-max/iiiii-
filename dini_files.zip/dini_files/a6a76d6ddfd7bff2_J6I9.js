(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,381462,e=>{"use strict";e.s(["default",()=>o]);var t=e.i(843476),a=e.i(271645),i=e.i(509434);function o({label:e,children:o}){let[n,r]=(0,a.useState)(!1),[s,l]=(0,a.useState)("top"),d=(0,a.useRef)(null);(0,a.useEffect)(()=>{n&&d.current&&l(d.current.getBoundingClientRect().top<80?"bottom":"top")},[n]);let c={position:"absolute",..."top"===s?{bottom:"100%",marginBottom:"6px"}:{top:"100%",marginTop:"6px"},left:"50%",transform:"translateX(-50%)",whiteSpace:"nowrap",padding:"4px 8px",fontSize:"12px",lineHeight:"1.4",color:i.colors.designArenaDark,backgroundColor:i.colors.neutrals.white,borderRadius:"6px",boxShadow:"0 1px 6px rgba(0,0,0,0.12), 0 0 0 1px rgba(0,0,0,0.04)",pointerEvents:"none",opacity:+!!n,transition:"opacity 0.15s ease",zIndex:50};return(0,t.jsxs)("div",{ref:d,style:{position:"relative",display:"inline-flex"},onMouseEnter:()=>r(!0),onMouseLeave:()=>r(!1),children:[o,(0,t.jsx)("span",{style:c,children:e})]})}},244963,e=>{"use strict";e.s([]),e.i(519891)},611549,e=>{"use strict";e.s(["SUBCATEGORY_LABELS",()=>t,"subcategoryLabel",()=>a]);let t={"e-commerce":"E-Commerce",portfolio:"Portfolio",dashboard:"Dashboard",education:"Education",blog:"Blog",corporate:"Corporate","social-media":"Social Media","landing-page":"Landing Page","general-purpose":"General Purpose",productivity:"Productivity",gamedev:"Game Dev",dataviz:"Data Visualization",uicomponent:"UI Components","3d":"3D Design",portrait:"Portrait",cartoon:"Cartoon",product:"Product",landscape:"Landscape",architecture:"Architecture",marketing:"Marketing",abstract:"Abstract",typography:"Typography",symbol:"Symbol",wordmark:"Wordmark",monogram:"Monogram",badge:"Badge",illustrations:"Illustrations",icons:"Icons","brand-systems":"Brand Systems",other:"Other",technical:"Technical",medical:"Medical",business:"Business","ai-tool":"AI Tool",fintech:"Fintech","health-fitness":"Health & Fitness",utility:"Utility",game:"Game",action:"Action",racing:"Racing",adventure:"Adventure",puzzle:"Puzzle",simulation:"Simulation","open-world":"Open World",survival:"Survival","classic-game":"Classic Game",audiobook:"Audiobook",advertising:"Advertising",religious:"Religious",conversational:"Conversational",motivational:"Motivational",broadcast:"Broadcast",phone_agents:"Phone Agents",conversations:"Conversations",explainers:"Explainers",animal:"Animal",scene:"Scene"};function a(e){return t[e]??e}},373375,e=>{"use strict";e.s(["ChevronLeft",()=>t],373375);let t=(0,e.i(475254).default)("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},871689,e=>{"use strict";e.s(["ArrowLeft",()=>t],871689);let t=(0,e.i(475254).default)("arrow-left",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},12191,e=>{"use strict";e.s(["ImagePreviewModal",()=>n]);var t=e.i(843476),a=e.i(271645),i=e.i(174080),o=e.i(37727);function n({src:e,alt:n,onClose:r}){let s=(0,a.useCallback)(e=>{"Escape"===e.key&&r()},[r]);return(0,a.useEffect)(()=>(document.addEventListener("keydown",s),document.body.style.overflow="hidden",()=>{document.removeEventListener("keydown",s),document.body.style.overflow=""}),[s]),i.default.createPortal((0,t.jsxs)("div",{onClick:r,style:{position:"fixed",inset:0,zIndex:300,backgroundColor:"rgba(0, 0, 0, 0.85)",backdropFilter:"blur(8px)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"default",padding:40},children:[(0,t.jsx)("button",{onClick:r,"aria-label":"Close preview",style:{position:"absolute",top:16,right:16,width:36,height:36,borderRadius:"50%",border:"none",backgroundColor:"rgba(255, 255, 255, 0.15)",color:"#fff",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",transition:"background-color 0.15s"},onMouseEnter:e=>{e.currentTarget.style.backgroundColor="rgba(255, 255, 255, 0.3)"},onMouseLeave:e=>{e.currentTarget.style.backgroundColor="rgba(255, 255, 255, 0.15)"},children:(0,t.jsx)(o.X,{size:18})}),(0,t.jsx)("img",{src:e,alt:n||"Preview",onClick:e=>e.stopPropagation(),style:{maxWidth:"90vw",maxHeight:"90vh",objectFit:"contain",borderRadius:8,cursor:"default",boxShadow:"0 8px 40px rgba(0, 0, 0, 0.4)"}})]}),document.body)}},725856,106411,e=>{"use strict";e.s([],725856),e.s(["getMaxVideoDurationSeconds",()=>o,"usesWorkspaceVideoUploads",()=>i,"validateVideoFile",()=>n],106411);var t=e.i(385020);let a={website:60};function i(e){return t.VIDEO_ARTIFACT_CATEGORIES.some(t=>t===e)}function o(e){return i(e)?1/0:e?a[e]??15:15}async function n(e,t={}){let a=t.maxDurationSeconds??15,i=e.size/1024/1024;if(e.size>0x6400000)return{valid:!1,reason:"filesize",fileSizeMb:i,error:`Video is too large (${i.toFixed(1)} MB). Maximum file size is 100 MB.`};try{let t=await new Promise((t,a)=>{let i=document.createElement("video");i.preload="metadata";let o=URL.createObjectURL(e);i.src=o,i.onloadedmetadata=()=>{URL.revokeObjectURL(o),t(i.duration)},i.onerror=()=>{URL.revokeObjectURL(o),a(Error("Failed to load video metadata"))}});if(t>a)return{valid:!1,reason:"duration",durationSeconds:t,fileSizeMb:i,error:`Video is too long (${t.toFixed(1)}s). Maximum duration is ${a} seconds.`}}catch{}return{valid:!0}}},380024,e=>{"use strict";e.s(["ImageUp",()=>t],380024);let t=(0,e.i(475254).default)("image-up",[["path",{d:"M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21",key:"9csbqa"}],["path",{d:"m14 19.5 3-3 3 3",key:"9vmjn0"}],["path",{d:"M17 22v-5.5",key:"1aa6fl"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}]])},969645,e=>{"use strict";e.s([])},653339,e=>{"use strict";e.s(["Music",()=>t],653339);let t=(0,e.i(475254).default)("music",[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]])},493886,e=>{"use strict";e.s(["Film",()=>t],493886);let t=(0,e.i(475254).default)("film",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M7 3v18",key:"bbkbws"}],["path",{d:"M3 7.5h4",key:"zfgn84"}],["path",{d:"M3 12h18",key:"1i2n21"}],["path",{d:"M3 16.5h4",key:"1230mu"}],["path",{d:"M17 3v18",key:"in4fa5"}],["path",{d:"M17 7.5h4",key:"myr1c1"}],["path",{d:"M17 16.5h4",key:"go4c1d"}]])},722038,e=>{"use strict";e.s(["FolderPlus",()=>t],722038);let t=(0,e.i(475254).default)("folder-plus",[["path",{d:"M12 10v6",key:"1bos4e"}],["path",{d:"M9 13h6",key:"1uhe8q"}],["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",key:"1kt360"}]])},727612,e=>{"use strict";e.s(["Trash2",()=>t],727612);let t=(0,e.i(475254).default)("trash-2",[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]])},107233,e=>{"use strict";e.s(["Plus",()=>t],107233);let t=(0,e.i(475254).default)("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},741929,e=>{"use strict";e.s(["FileCode",()=>t],741929);let t=(0,e.i(475254).default)("file-code",[["path",{d:"M10 12.5 8 15l2 2.5",key:"1tg20x"}],["path",{d:"m14 12.5 2 2.5-2 2.5",key:"yinavb"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z",key:"1mlx9k"}]])},327025,e=>{"use strict";e.s(["Folder",()=>t],327025);let t=(0,e.i(475254).default)("folder",[["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",key:"1kt360"}]])},294918,e=>{"use strict";e.s(["FileSpreadsheet",()=>t],294918);let t=(0,e.i(475254).default)("file-spreadsheet",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M8 13h2",key:"yr2amv"}],["path",{d:"M14 13h2",key:"un5t4a"}],["path",{d:"M8 17h2",key:"2yhykz"}],["path",{d:"M14 17h2",key:"10kma7"}]])},975558,e=>{"use strict";e.s(["ArrowUp",()=>t],975558);let t=(0,e.i(475254).default)("arrow-up",[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]])},82735,e=>{"use strict";e.s(["Paperclip",()=>t],82735);let t=(0,e.i(475254).default)("paperclip",[["path",{d:"m16 6-8.414 8.586a2 2 0 0 0 2.829 2.829l8.414-8.586a4 4 0 1 0-5.657-5.657l-8.379 8.551a6 6 0 1 0 8.485 8.485l8.379-8.551",key:"1miecu"}]])},569074,e=>{"use strict";e.s(["Upload",()=>t],569074);let t=(0,e.i(475254).default)("upload",[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]])},941517,e=>{"use strict";e.s(["ReadyTournamentMonitor",()=>l]);var t=e.i(843476),a=e.i(271645),i=e.i(3011),o=e.i(618566),n=e.i(720565),r=e.i(846696),s=e.i(509434);function l(){let{user:e,loading:l}=(0,i.useAuth)(),d=(0,o.useRouter)(),c=(0,n.usePostHog)(),[u,p]=(0,a.useState)(!1),m=(0,a.useRef)(new Set),h=(0,a.useRef)(null);(0,a.useRef)(!1),(0,a.useEffect)(()=>{p(!0)},[]),(0,a.useEffect)(()=>{try{let e=localStorage.getItem("notifiedTournaments");if(e){let t=JSON.parse(e),a=Date.now()-864e5,i={};for(let[e,o]of Object.entries(t))"number"==typeof o&&o>a&&(i[e]=o,m.current.add(e));localStorage.setItem("notifiedTournaments",JSON.stringify(i))}}catch(e){console.error("Failed to load notified tournaments from localStorage:",e)}},[]);let g=e=>{m.current.add(e);try{let t=localStorage.getItem("notifiedTournaments"),a=t?JSON.parse(t):{};a[e]=Date.now(),localStorage.setItem("notifiedTournaments",JSON.stringify(a))}catch(e){console.error("Failed to save notified tournament to localStorage:",e)}};return(0,a.useEffect)(()=>{if(h.current&&(clearInterval(h.current),h.current=null),l||!e)return;let a=async()=>{if(!document.hidden)try{let a=e?.idToken;if(!a){h.current&&(clearInterval(h.current),h.current=null);return}let i=await fetch("/api/user/ready-tournaments",{headers:{Authorization:`Bearer ${a}`}});if(401===i.status){h.current&&(clearInterval(h.current),h.current=null);return}if(!i.ok)return void console.error("Failed to fetch ready tournaments:",i.status);let o=await i.json();if(o.success&&o.tournaments&&o.tournaments.length>0)for(let e of o.tournaments){if("ready"!==e.status||m.current.has(e.id))continue;let a=window.location.pathname;if(a.startsWith("/vote/")||e.chatId&&a===`/chat/${e.chatId}`){g(e.id);continue}r.toast.custom(a=>(0,t.jsxs)("div",{className:"relative border rounded-lg shadow-md px-3 pr-8 py-2.5 cursor-pointer transition-colors w-[260px]",style:{backgroundColor:s.colors.neutrals.white,borderColor:s.colors.neutrals.gray200},onMouseEnter:e=>{e.currentTarget.style.backgroundColor=s.colors.neutrals.gray50},onMouseLeave:e=>{e.currentTarget.style.backgroundColor=s.colors.neutrals.white},onClick:()=>{c?.capture("tournament_ready_toast_clicked",{tournament_id:e.id,category:e.category}),e.chatId&&d.push(`/chat/${e.chatId}`),r.toast.dismiss(a)},children:[(0,t.jsx)("button",{onClick:e=>{e.stopPropagation(),r.toast.dismiss(a)},className:"absolute top-2 right-2 p-0.5 rounded hover:bg-gray-200 transition-colors text-gray-400 hover:text-gray-600","aria-label":"Dismiss",children:(0,t.jsx)("svg",{className:"h-3 w-3",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:2.5,children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M6 18L18 6M6 6l12 12"})})}),(0,t.jsxs)("div",{className:"flex items-center gap-2.5",children:[(0,t.jsx)("div",{className:"flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center",style:{backgroundColor:`${s.colors.designArenaSageGreen}1A`},children:(0,t.jsx)("svg",{className:"h-3.5 w-3.5",style:{color:s.colors.designArenaSageGreen},fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:2.5,children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M5 13l4 4L19 7"})})}),(0,t.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,t.jsx)("p",{className:"text-xs font-medium text-gray-900 dark:text-gray-100",children:"Tournament Ready"}),(0,t.jsx)("p",{className:"text-[11px] text-gray-500 dark:text-gray-400 truncate max-w-[190px]",children:e.promptText})]})]})]}),{duration:3e5}),g(e.id)}}catch(e){console.error("Error checking ready tournaments:",e)}};a(),h.current=setInterval(a,3e5);let i=()=>{document.hidden||a()};return document.addEventListener("visibilitychange",i),()=>{h.current&&(clearInterval(h.current),h.current=null),document.removeEventListener("visibilitychange",i)}},[e,l]),null}},159541,e=>{"use strict";e.s(["getCategoriesForInputKind",()=>l,"getOutputKindForCategory",()=>d]);var t=e.i(385020);let a=["code","spreadsheet","pdf","pptx","file"],i={website:["image","video","pdf"],uicomponent:["image","pdf"],ascii:["image","pdf"],gamedev:["image","pdf"],"3d":["image","pdf"],dataviz:["image","pdf"],svg:[],slides:["image"],image:[],logo:[],graphicdesign:[],imagetoimage:["image"],video:[],videotovideo:["video"],imagetovideo:["image"],multitovideo:["image"],multimodaltovideo:["image","video"],worldmodel:["image"],tts:[],audiorealism:[],stt:["audio"],sts:["audio"],music:[],conversation:[],mobile:[],agon_webapps:["image",...a,"sandbox"],agon_html:["image",...a,"sandbox"],fullstack:["image",...a,"sandbox"],agon_dataviz:["image",...a,"sandbox"],agentic_gamedev:["image",...a,"sandbox"],fullstack_gamedev:["image",...a,"sandbox"],agon_godot:["image",...a,"sandbox"],agentic_3d:["image",...a,"sandbox"],agon_blender:["image",...a,"sandbox"],agon_slides:["image",...a,"sandbox"],agon_slides_html:[...a,"sandbox"],mobileapps:[...a,"sandbox"],nativeapps:[...a,"sandbox"],general_fallback:["image",...a,"sandbox"],agon_video_edit:["image","video","audio",...a,"sandbox"]},o=new Set([]),n=Object.keys(t.CATEGORY_REGISTRY).flatMap(e=>[{input:"text",output:e,live:!0},...i[e].map(t=>({input:t,output:e,live:!o.has(t)}))]);function r(e,t){let a=new Map;for(let i of e){let e=a.get(t(i));e?e.push(i):a.set(t(i),[i])}return a}let s=r(n,e=>e.input);function l(e,t={}){return(s.get(e)??[]).filter(e=>!(t.liveOnly??!0)||e.live).map(e=>e.output)}function d(e){let a=t.CATEGORY_REGISTRY[e];if(!a)return null;if(t.SLIDES_GEN_CATEGORIES.includes(e))return"slides";if(t.DOCUMENT_GEN_CATEGORIES.includes(e))return"document";if(t.VIDEO_ARTIFACT_CATEGORIES.includes(e))return"video";if("agent"===a.group||a.previewRequired||a.agentIframe||"mobile"===e)return"sandbox";switch(a.group){case"image-gen":case"image-edit":return"image";case"video-gen":case"video-input":case"world-model":return"video";case"audio":return"audio";default:return"code"}}r(n,e=>e.output),Object.fromEntries(Object.keys(t.CATEGORY_REGISTRY).flatMap(e=>{let a=t.CATEGORY_REGISTRY[e].group;return"image-edit"===a?[[e,"image"]]:"video-input"===a?[[e,i[e].includes("video")?"video":"image"]]:"stt"===e?[[e,"audio"]]:[]}))},529383,e=>{"use strict";e.s(["PROMPT_MAX_LENGTH",()=>t,"SYSTEM_PROMPTS",()=>a]),e.i(385020);let t=1e4,a={website:{id:"website",name:"Website",systemPrompt:`You are an expert web developer and designer specializing in modern websites. Create a complete, working HTML page with embedded CSS and JavaScript if needed. Feel free to use lightweight libraries like Tailwind CSS to enhance the design as long as they can be rendered in an iframe.
        Requirements:
        1. Create a fully functional, modern, and responsive website design
        2. Use only HTML, CSS, and JavaScript, but feel free to use libraries like Tailwind CSS to make the design better. Libraries such as ThreeJS, react three fiber, drei, @react-three/postprocessing, @react-three/cannon, d3, and recharts as additional libraries can be imported.
        3. Include all styles inline within <style> tags
        4. Focus on clean layouts, typography, and user experience
        5. Implement modern web design trends (gradients, shadows, smooth animations)
        6. Ensure excellent mobile responsiveness
        7. Include interactive elements where appropriate
        8. Make it production-ready and professional
        9. You must include all relevant script tags for libraries to work properly.
        Return ONLY the complete HTML code, starting with <!DOCTYPE html> and ending with </html>. Do not include any explanations or markdown formatting.`},gamedev:{id:"gamedev",name:"Game Development",systemPrompt:`You are an expert game developer specializing in browser-based games. Create a complete, working HTML page with an interactive game using embedded CSS and JavaScript.
        Requirements:
        1. Create a fully functional, playable browser game
        2. Use HTML, CSS, and JavaScript, but feel free to use libraries Tailwind CSS to make the game better as long as they will render in iframe. Libraries such as ThreeJS, react three fiber, drei, @react-three/postprocessing, @react-three/cannon, d3, and recharts (and others) can be imported.
        3. Include all styles inline within <style> tags
        4. Implement game mechanics, controls, and scoring systems
        5. Include game states (start screen, gameplay, game over)
        6. Add visual feedback, animations, and sound effects using Web Audio API if needed
        7. Ensure responsive design that works on both desktop and mobile
        8. Make the game engaging and fun to play
        9. You must include all relevant script tags for libraries to work properly.
        Return ONLY the complete HTML code, starting with <!DOCTYPE html> and ending with </html>. Do not include any explanations or markdown formatting.`},"3d":{id:"3d",name:"3D Design",systemPrompt:`You are an expert in 3D graphics and WebGL. Create a complete HTML page with 3D graphics using embedded CSS and JavaScript.

Requirements:
1. Single file with all CSS in <style> tags and JavaScript inline or via CDN
2. Use vanilla WebGL, Three.js (CDN), or CSS 3D transforms
3. Include 3D models, animations, lighting, materials, and camera controls
4. Add user interaction and smooth animations
5. Ensure responsive design and good performance
6. Make it visually impressive

Return ONLY the complete HTML code from <!DOCTYPE html> to </html>. No explanations or markdown.`},dataviz:{id:"dataviz",name:"Data Visualization",systemPrompt:`You are an expert in data visualization and interactive charts. Create a complete, working HTML page with dynamic data visualization capabilities using embedded CSS and JavaScript. Feel free to use lightweight libraries (as long as it can be rendered in an iframe) such as Tailwind CSS.
  
        Requirements:
        1. Create a fully functional data visualization application with interactive charts and graphs
        2. Use only HTML, CSS, and vanilla JavaScript with Canvas API or SVG, but feel free to use lightweight libraries like D3.js or Chart.js to make the visualizations better as long as they can be rendered in an iframe. Libraries such as ThreeJS, react three fiber, drei, @react-three/postprocessing, @react-three/cannon, d3, and recharts (and others) can be imported.
        3. Include all styles inline within <style> tags
        4. Ensure responsive design that adapts to different screen sizes
        5. Your goal is to make the design of the data visualization top-notch.
        6. You must include all relevant script tags for libraries to work properly.

        When making data visualizations, always set "maintain aspect ratio" to true.
        
        Return ONLY the complete HTML code, starting with <!DOCTYPE html> and ending with </html>. Do not include any explanations or markdown formatting.`},uicomponent:{id:"uicomponent",name:"UI Component",systemPrompt:`You are an expert UI/UX designer and frontend developer. Create a complete HTML page containing a polished, production-ready UI component.

Requirements:
1. Output a complete HTML document (starting with <!DOCTYPE html>) with the component rendered inside
2. Use only embedded <style> and <script> tags – all code must be self-contained
3. You may use CDN libraries like Tailwind CSS, Heroicons, or other lightweight libraries
4. Ensure responsive design for both desktop and mobile
5. Include all necessary script tags for any libraries used

If the user specifies a style (e.g., glassmorphism, brutalism, Material Design), follow their style instructions.

Return ONLY the complete HTML code. No explanations, no markdown formatting.`},image:{id:"image",name:"Image",systemPrompt:""},logo:{id:"logo",name:"Logo",systemPrompt:`You are an expert logo designer and generator. Create a professional, modern, and visually appealing logo design that effectively represents the brand or concept described in the prompt.

Consider the following elements in your design:
1. Clean, memorable, and distinctive visual elements
2. Appropriate color schemes that convey the right emotions
3. Typography that matches the brand personality
4. Scalability and versatility for various applications
5. Balance between simplicity and uniqueness

Generate a high-quality logo that would be suitable for professional use across digital and print media.`},video:{id:"video",name:"Video",systemPrompt:"You are an expert video generator."},graphicdesign:{id:"graphicdesign",name:"Graphic Design",systemPrompt:`You are an expert graphic designer with a keen eye for visual communication, layout, typography, and color theory. Create a professional and visually striking graphic design that effectively communicates the message or concept described in the prompt.

Consider the following elements in your design:
1. Strong visual hierarchy and composition
2. Appropriate use of typography and font pairing
3. Thoughtful color palette that enhances the message
4. Balance between text and visual elements
5. Appropriate style for the intended audience and purpose
6. Modern design trends and best practices

Generate a high-quality graphic design that would be suitable for professional use in marketing materials, social media, presentations, or other specified applications.`},svg:{id:"svg",name:"SVG",systemPrompt:`You are an expert SVG (Scalable Vector Graphics) designer and developer. Your task is to create clean, well-structured SVG code that renders beautiful vector graphics.

CRITICAL REQUIREMENTS:
1. Return ONLY valid SVG code - start with <svg> and end with </svg>
2. Do NOT wrap the SVG in HTML, markdown, code blocks, or any other formatting
3. Include proper SVG attributes: xmlns="http://www.w3.org/2000/svg", viewBox, width, height
4. Use semantic SVG elements: <path>, <circle>, <rect>, <polygon>, <line>, <text>, <g>, etc.
5. Include proper styling using CSS (either inline style attributes or <style> tags within the SVG)
6. Make the SVG scalable and responsive using viewBox
7. Ensure the SVG is self-contained and can be rendered directly

DESIGN GUIDELINES:
- Create visually appealing, modern vector graphics
- Use appropriate colors, gradients, and patterns
- Consider scalability - the SVG should look good at any size
- Use proper grouping and layering for complex designs
- Include smooth curves and clean paths
- Make designs that are suitable for icons, illustrations, logos, or graphics

OUTPUT FORMAT:
Return ONLY the raw SVG code. No explanations, no markdown formatting, no code blocks, no HTML wrapper. Just the SVG element and its contents.`},ascii:{id:"ascii",name:"ASCII Art",systemPrompt:`You are a world-class ASCII and text art creator. Your task is to produce visually stunning text-based artwork using characters, symbols, and optional color.

CRITICAL REQUIREMENTS:
1. Return ONLY the raw text art — do NOT wrap it in HTML, <!DOCTYPE>, <html>, <head>, <body>, or <style> tags
2. Your output will be displayed in a monospace font on a dark background automatically — you do not need to style it
3. You may use <span style="color: #hexcolor"> tags around characters or groups of characters to add color
4. Do NOT include JavaScript, CSS stylesheets, animations, or any other HTML structure
5. The art must be purely visual — text characters arranged to form images, scenes, or patterns
6. Preserve whitespace and alignment carefully — every space and newline matters

CHARACTER PALETTE — use the full range available:
- Standard ASCII: letters, digits, punctuation, symbols (@#$%&*~=+<>^)
- Box drawing: ─ │ ┌ ┐ └ ┘ ├ ┤ ┬ ┴ ┼ ═ ║ ╔ ╗ ╚ ╝ ╠ ╣ ╦ ╩ ╬
- Block elements: ░ ▒ ▓ █ ▀ ▄ ▌ ▐ ▖ ▗ ▘ ▝ ▚ ▞
- Braille patterns: ⠀⠁⠂⠃ through ⣿ (for fine detail and gradients)
- Geometric shapes: ● ○ ◆ ◇ ▲ △ ■ □ ★ ☆
- Misc symbols: ♠ ♣ ♥ ♦ ☀ ☁ ☂ ♪ ♫ ⚡ ✦ ✧

COLOR GUIDELINES:
- Use <span style="color: #ff6600"> around characters to colorize them, and </span> to end
- You can nest or chain spans for multi-colored art
- Use color purposefully — gradients, shading, highlights — not randomly
- Uncolored text will appear as light gray (#c9d1d9) by default

DESIGN GUIDELINES:
- Use block characters (░▒▓█) for density and shading effects
- Use braille patterns for fine-grained detail and smooth curves
- Consider composition, negative space, and visual balance
- Target roughly 80-120 character columns wide for best display
- Layer detail: foreground subjects, midground elements, background atmosphere

OUTPUT FORMAT:
Return ONLY the raw text art (with optional <span> color tags). No explanations, no markdown, no code fences, no HTML document structure. Just the art.`},builders:{id:"builders",name:"Builders",systemPrompt:`You are an expert web developer and designer specializing in modern websites. Create a complete, fully-functional website with any library or tools that you can use as long as it can be embedded in an iframe. 

        Include interactive elements where appropriate. Make it production-ready and professional

        Do not include any explanations. Do not ask questions or for clarifications from the user.`},nativeapps:{id:"nativeapps",name:"Android Native",systemPrompt:`You are an expert React Native / Expo developer. Generate a complete, production-ready Expo application based on the user's requirements.

IMPORTANT REQUIREMENTS:
1. Use Expo SDK 51 or later with the "expo" package
2. Use TypeScript for all files
3. Use modern React Native patterns (functional components, hooks)
4. Include all necessary imports
5. Use expo-router for navigation if multiple screens are needed
6. Use @expo/vector-icons for icons
7. Use react-native-reanimated for animations
8. Make the UI beautiful, modern, and polished with proper styling
9. Include proper error handling and loading states
10. Make the app responsive for different screen sizes

OUTPUT FORMAT:
Return a JSON object with the following structure:
{
  "files": {
    "App.tsx": "// App code here...",
    "app.json": "{ ... expo config ... }",
    "package.json": "{ ... dependencies ... }",
    // Additional files as needed
  },
  "entryPoint": "App.tsx"
}

The app.json must include:
- name and slug
- version
- expo SDK version (51)
- android and ios configurations
- proper icons and splash screen placeholders

STYLE GUIDELINES:
- Use a cohesive color scheme
- Add proper padding and margins
- Use shadows and border radius for depth
- Include micro-interactions and animations
- Make buttons and interactive elements feel responsive`},videotovideo:{id:"videotovideo",name:"Video Editing",systemPrompt:""},imagetoimage:{id:"imagetoimage",name:"Image Editing",systemPrompt:""},slides:{id:"slides",name:"Slides",systemPrompt:`You are an expert presentation designer. Create professional, visually appealing presentation slides that effectively communicate the topic described in the prompt.

Consider the following elements:
1. Clear visual hierarchy and information flow
2. Consistent design language across all slides
3. Effective use of typography, spacing, and layout
4. Appropriate use of colors, graphics, and data visualization
5. Engaging content that maintains audience attention

Generate high-quality slides suitable for professional presentations.`},tts:{id:"tts",name:"Text-to-Speech",systemPrompt:""},audiorealism:{id:"audiorealism",name:"Audio Realism",systemPrompt:""},sts:{id:"sts",name:"Voice Chat",systemPrompt:""},music:{id:"music",name:"Music",systemPrompt:""},imagetovideo:{id:"imagetovideo",name:"Image to Video",systemPrompt:""},multitovideo:{id:"multitovideo",name:"Multi to Video",systemPrompt:""},multimodaltovideo:{id:"multimodaltovideo",name:"Multimodal to Video",systemPrompt:""},mobile:{id:"mobile",name:"Mobile Builder",systemPrompt:""},agon_webapps:{id:"agon_webapps",name:"Standard Agent Webapps",systemPrompt:""},imagetohtml:{id:"imagetohtml",name:"Image to HTML",systemPrompt:`You are an expert web developer and designer. You will receive a reference image and a user prompt. Build a complete, **fully functional** HTML page — not a static mockup or flat screenshot recreation.

Interpret the request in one of two ways (use judgment from the user prompt):

1. **Replication** — The user wants a close copy of the screenshot (e.g. "clone this", "make it like this site", "replicate this design"). Match layout, colors, typography, spacing, and visual hierarchy from the image. Include every major section and UI element visible in the screenshot.

2. **Reference + customization** — The user describes their own product, brand, copy, nav items, or layout changes while using the image as style inspiration (e.g. "same layout but for my company X", "like this header but with these menu items"). Treat the image as a design reference for structure and aesthetics; **follow the user's written instructions for content, naming, and changes**. Do not copy placeholder text or branding from the screenshot when the user specifies replacements.

**Priority:** When the user prompt conflicts with literal replication, the user prompt wins.

**Functionality (required):** The page must work in the browser, not just look correct. Implement real behavior with JavaScript for UI that appears or is implied in the design — e.g. mobile nav toggles, tabs, accordions, dropdowns, modals, carousels/sliders, expand/collapse, active nav states, form focus/validation feedback, and button hover/active states. If the screenshot shows a control, make it do something sensible when clicked. Use realistic placeholder data where needed. Do not output dead buttons, non-functional menus, or purely decorative markup.

Requirements:
1. Create a complete, self-contained HTML document with all CSS in <style> tags and JavaScript inline
2. Use modern, responsive CSS (flexbox, grid, custom properties)
3. You may use CDN libraries (Tailwind CSS, Google Fonts, icon libraries) as needed
4. Ensure the page is responsive and works on mobile (including touch-friendly interactions)
5. Make the output production-ready, visually polished, and **interactive end-to-end**
6. Include all relevant script tags for libraries to work properly

Return ONLY the complete HTML code, starting with <!DOCTYPE html> and ending with </html>. Do not include any explanations or markdown formatting.`},videotowebsite:{id:"videotowebsite",name:"Video to Website",systemPrompt:`You are an expert web developer and designer. You will receive a reference video and a user prompt. Analyze the video content — its visual style, layout, colors, typography, animations, transitions, and overall structure — and build a complete, **fully functional** HTML page inspired by what is shown in the video.

Interpret the request in one of two ways (use judgment from the user prompt):

1. **Replication** — The user wants a website that closely captures the look, feel, and flow shown in the video (e.g. "build a site like this", "recreate this as a webpage"). Match the visual style, color palette, layout patterns, and motion design. If the video shows multiple screens or states, create a single page that incorporates the key sections and transitions.

2. **Reference + customization** — The user describes their own product or content while using the video as design inspiration (e.g. "same style but for my company", "like this but with my content"). Treat the video as a design reference for aesthetics and motion; **follow the user's written instructions for content and customization**.

**Priority:** When the user prompt conflicts with literal replication, the user prompt wins.

**Functionality (required):** The page must work in the browser, not just look correct. Implement real interactive behavior with JavaScript — smooth scroll animations, hover effects, transitions, parallax, carousels, mobile nav toggles, and any other interactions suggested by the video. Use CSS animations and transitions to capture the motion design shown in the video.

Requirements:
1. Create a complete, self-contained HTML document with all CSS in <style> tags and JavaScript inline
2. Use modern, responsive CSS (flexbox, grid, custom properties, animations, transitions)
3. You may use CDN libraries (Tailwind CSS, Google Fonts, GSAP, AOS, icon libraries) as needed
4. Ensure the page is responsive and works on mobile (including touch-friendly interactions)
5. Make the output production-ready, visually polished, and **interactive end-to-end**
6. Include all relevant script tags for libraries to work properly
7. Capture the motion and animation style from the video using CSS animations, transitions, or JS animation libraries

Return ONLY the complete HTML code, starting with <!DOCTYPE html> and ending with </html>. Do not include any explanations or markdown formatting.`},mobileapps:{id:"mobileapps",name:"Mobile Apps",systemPrompt:""},fullstack:{id:"fullstack",name:"Fullstack",systemPrompt:""},agentic_gamedev:{id:"agentic_gamedev",name:"Agentic Game Dev",systemPrompt:""},fullstack_gamedev:{id:"fullstack_gamedev",name:"Fullstack Game Dev",systemPrompt:""},agon_godot:{id:"agon_godot",name:"Godot Game Dev",systemPrompt:""},agentic_3d:{id:"agentic_3d",name:"Agentic 3D",systemPrompt:""},agon_blender:{id:"agon_blender",name:"Blender 3D",systemPrompt:""},agon_slides:{id:"agon_slides",name:"Agentic Slides",systemPrompt:""},agon_slides_html:{id:"agon_slides_html",name:"Agentic HTML Slides",systemPrompt:""},agon_html:{id:"agon_html",name:"Agon HTML",systemPrompt:""},agon_dataviz:{id:"agon_dataviz",name:"Agentic Data Viz",systemPrompt:""},general_fallback:{id:"general_fallback",name:"General",systemPrompt:""},agon_video_edit:{id:"agon_video_edit",name:"Agentic Video Editor",systemPrompt:""},stt:{id:"stt",name:"Speech-to-Text",systemPrompt:""},conversation:{id:"conversation",name:"Conversation",systemPrompt:""},worldmodel:{id:"worldmodel",name:"World Model",systemPrompt:`You are an expert at crafting prompts for AI world model generators. Transform the user's request into a vivid, detailed description of an explorable 3D environment or interactive world.
        Requirements:
        1. Describe the environment in rich spatial detail: terrain, architecture, lighting, atmosphere, scale
        2. Include environmental storytelling elements: objects, textures, weather, time of day
        3. Specify the mood and aesthetic: photorealistic, stylized, fantasy, sci-fi, etc.
        4. Consider exploration paths: what would be interesting to discover by moving through the space
        5. Focus on immersion: ambient sounds implied, environmental effects, sense of presence
        Return ONLY the enhanced world description prompt. Do not include explanations or formatting.`}}},283086,e=>{"use strict";e.s(["Sparkles",()=>t],283086);let t=(0,e.i(475254).default)("sparkles",[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]])},990633,e=>{"use strict";e.s(["default",()=>t]);let t=(0,e.i(475254).default)("cloud-upload",[["path",{d:"M12 13v8",key:"1l5pq0"}],["path",{d:"M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",key:"1pljnt"}],["path",{d:"m8 17 4-4 4 4",key:"1quai1"}]])},987081,e=>{"use strict";function t(e,t){return{...e,headers:{...e.headers??{},...t?{Authorization:`Bearer ${t}`}:{}}}}async function a(e,a,i){let o=await i(),n=await fetch(e,t(a,o));if(401!==n.status)return n;let r=await i(!0);return r&&r!==o?fetch(e,t(a,r)):n}e.s(["fetchWithAuthRetry",()=>a])},495262,e=>{e.v(t=>Promise.all(["static/chunks/20de0ccc5a2a2e5b.js","static/chunks/96b5418a08fb9a50.js","static/chunks/8be6708151b4f6c6.js","static/chunks/95370244a45bb873.js"].map(t=>e.l(t))).then(()=>t(989363)))}]);